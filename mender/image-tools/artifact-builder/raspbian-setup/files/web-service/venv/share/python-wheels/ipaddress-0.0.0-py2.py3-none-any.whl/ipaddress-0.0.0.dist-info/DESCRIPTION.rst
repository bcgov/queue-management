Port of the 3.3+ ipaddress module to 2.6, 2.7, 3.2


